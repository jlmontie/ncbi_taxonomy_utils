# NCBI taxonomy utilities

This is a package for NCBI taxonomy utilities

Followed example verbatim at https://packaging.python.org/tutorials/packaging-projects/

To update, run ncbi_taxonomy_utils_constructor.py to generate new pickle resource files

Command to build: python3 setup.py sdist bdist_wheel

Command to install: pip install git+https://github.com/idbydna/taxonomer.git@snakemake_dev#subdirectory=utils/ncbi_taxonomy_utils_package