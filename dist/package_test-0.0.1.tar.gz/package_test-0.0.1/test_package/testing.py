def test():
    print("This is a test. Testing... testing... testing ...")